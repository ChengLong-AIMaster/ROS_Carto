AMCL project
To compile.

$cd path of amcl_ws
$catkin_make
$catkin_make install
