AMCL project
To compile.

$cd path of move_base_ws
$catkin_make
$catkin_make install
